package config

var (
	SECRET     string
	SERVERPORT int16
)
