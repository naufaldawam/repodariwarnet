package delivery

type BookResponse struct {
	ID       int
	Judul    string
	Penerbit string
	Pemilik  int
}
