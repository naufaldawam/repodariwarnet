### Penjelasan project

## Setup Action
1. Masuk ke menu `Action`
2. Pilih action yang akan digunakan, jika tidak silahkan pilih `setup your own`
3. Tambahkan variable yang dibutuhkan untuk menjalankan action pada bagian secret