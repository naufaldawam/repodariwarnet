package data

// import (
// 	"errors"
// 	"socialmediabackendproject/domain"

// 	"gorm.io/gorm"
// )

// type postData struct{
// 	db *gorm.DB
// }

// func New(DB *gorm.DB) domain.PostData {
// 	return &postData{
// 		db: DB,
// 	}
// }

// func (pd *postData) insertPost(newPost domain.Post) (domain.Post, error){
// 	var newPost Post = ToEntity(newPost)
// 	res := up.db.Where("id = ?", ).
// }
