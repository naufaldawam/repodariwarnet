package delivery

import "socialmediabackendproject/domain"

type GetUser struct {
	ID                   uint
	Name                 string
	Email                string
	Profile_picture_path string
}

func ToGetUser(data domain.User) GetUser {
	return GetUser{
		ID:                   data.ID,
		Name:                 data.Name,
		Email:                data.Email,
		Profile_picture_path: data.Profile_picture_path,
	}
}

type GetSpecificUser struct {
	ID                   uint
	Name                 string
	Email                string
	Profile_picture_path string
	Address              string
	Gender               bool
	Bod                  string
}

func ToGetSpecificUser(data domain.User) GetSpecificUser {
	return GetSpecificUser{
		ID:                   data.ID,
		Name:                 data.Name,
		Email:                data.Email,
		Profile_picture_path: data.Profile_picture_path,
		Gender:               data.Gender,
		Bod:                  data.Bod,
	}
}

type GetUpdateUser struct{
	ID                   uint
	Name                 string
	Email                string
	Profile_picture_path string
	Address              string
	Gender               bool
	Bod                  string
}

func ToUpdateUser(data domain.User) GetUpdateUser{
	return GetUpdateUser{
		ID:                   data.ID,
		Name:                 data.Name,
		Email:                data.Email,
		Profile_picture_path: data.Profile_picture_path,
		Gender:               data.Gender,
		Bod:                  data.Bod,
	}
}