package domain

type Post_Image struct {
	ID         uint
	Post_ID    uint
	Created_At string
}
