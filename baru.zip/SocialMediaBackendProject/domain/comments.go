package domain

type Comment struct {
	ID         uint
	User_ID    uint
	Post_ID    uint
	Caption    uint
	Created_At string
	Updated_At string
}
