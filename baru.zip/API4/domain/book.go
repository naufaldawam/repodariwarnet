package domain

import "github.com/labstack/echo/v4"

type Book struct {
	ID       int
	Judul    string `json:"judul" form:"judul"`
	Penerbit string `json:"penerbit" form:"penerbit"`
	ISBN     string
	Pemilik  int
}

type BookHandler interface {
	InsertBook() echo.HandlerFunc
	DeleteBook() echo.HandlerFunc
	UpdateBook() echo.HandlerFunc
	GetAllBook() echo.HandlerFunc
	GetMyBook() echo.HandlerFunc
}

type BookUseCase interface {
	GetAllB() ([]Book, error)
	GetMyB(IDUser int) ([]Book, error)
	AddBook(IDUser int, newBook Book) (Book, error)
	DelBook(IDBook int) (bool, error)
	UpBook(IDBook int, updateData Book) (Book, error)
}

type BookData interface {
	GetAll() []Book
	GetMy(IDUser int) []Book
	Insert(newBook Book) Book
	Delete(IDBook int) bool
	Update(IDBook int, updatedBook Book) Book
}
