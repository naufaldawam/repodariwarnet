package domain

import "github.com/labstack/echo/v4"

type User struct {
	ID       int
	Nama     string
	Email    string
	Password string
}

type UserHandler interface {
	InsertUser() echo.HandlerFunc
	DeleteUser() echo.HandlerFunc
	UpdateUser() echo.HandlerFunc
	GetAllUser() echo.HandlerFunc
	GetUser() echo.HandlerFunc
}

type UserUseCase interface {
	AddUser(newUser User) (User, error)
	GetAll() ([]User, error)
	GetProfile(id int) (User, error)
	DeleteProfile(userID int) (bool, error)
	UpdateProfile(userID int, updatedData User) (User, error)
}

type UserData interface {
	Insert(newUser User) (User, error)
	GetAll() ([]User, error)
	GetSpecific(userID int) (User, error)
	Delete(userID int) bool
	Update(userID int, updatedData User) User
}
