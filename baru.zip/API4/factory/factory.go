package factory

import (
	"gorm.io/gorm"

	bd "API4/feature/book/data"
	bookDelivery "API4/feature/book/delivery"

	"github.com/go-playground/validator/v10"
	"github.com/labstack/echo/v4"

	bs "API4/feature/book/usecase"

	ud "API4/feature/user/data"
	userDelivery "API4/feature/user/delivery"
	us "API4/feature/user/usecase"
)

func InitFactory(e *echo.Echo, db *gorm.DB) {
	userData := ud.New(db)
	validator := validator.New()
	useCase := us.New(userData, validator)
	userHandler := userDelivery.New(useCase)
	userDelivery.RouteBook(e, userHandler)

	bookData := bd.New(db)
	bookCase := bs.New(bookData)
	bookHandler := bookDelivery.New(bookCase)
	bookDelivery.RouteBook(e, bookHandler)
}
