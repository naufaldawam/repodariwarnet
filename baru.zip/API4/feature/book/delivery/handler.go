package delivery

import (
	"log"
	"net/http"
	"strconv"
	"strings"

	"API4/domain"
	"API4/feature/common"

	"github.com/labstack/echo/v4"
)

type bookHandler struct {
	bookUsecase domain.BookUseCase
}

func New(bu domain.BookUseCase) domain.BookHandler {
	return &bookHandler{
		bookUsecase: bu,
	}
}

func (bh *bookHandler) InsertBook() echo.HandlerFunc {
	return func(c echo.Context) error {
		var tmp BookInsertRequest
		err := c.Bind(&tmp)

		if err != nil {
			log.Println("Cannot parse data", err)
			c.JSON(http.StatusBadRequest, "error read input")
		}

		data, err := bh.bookUsecase.AddBook(common.ExtractData(c), tmp.ToDomain())

		if err != nil {
			log.Println("Cannot proces data", err)
			c.JSON(http.StatusInternalServerError, err)
		}

		return c.JSON(http.StatusCreated, map[string]interface{}{
			"message": "success create data",
			"data":    data,
		})

	}
}

func (bh *bookHandler) GetAllBook() echo.HandlerFunc {
	return func(c echo.Context) error {
		data, err := bh.bookUsecase.GetAllB()

		if err != nil {
			log.Println("Cannot get data", err)
			c.JSON(http.StatusBadRequest, "error read input")
		}

		if data == nil {
			log.Println("Terdapat error saat mengambil data")
			return c.JSON(http.StatusInternalServerError, "Problem from database")
		}

		return c.JSON(http.StatusOK, map[string]interface{}{
			"message": "success get all book",
			"users":   data,
		})
	}
}

func (bh *bookHandler) GetMyBook() echo.HandlerFunc {
	return func(c echo.Context) error {
		data, err := bh.bookUsecase.GetMyB(common.ExtractData(c))

		if err != nil {
			log.Println("Cannot get data", err)
			c.JSON(http.StatusBadRequest, "error read input")
		}

		return c.JSON(http.StatusOK, map[string]interface{}{
			"message": "success get my book",
			"users":   data,
		})
	}
}

func (bh *bookHandler) DeleteBook() echo.HandlerFunc {
	return func(c echo.Context) error {

		cnv, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			log.Println("Cannot convert to int", err.Error())
			return c.JSON(http.StatusInternalServerError, "cannot convert id")
		}

		data, err := bh.bookUsecase.DelBook(cnv)

		if err != nil {
			if strings.Contains(err.Error(), "not found") {
				return c.JSON(http.StatusNotFound, err.Error())
			} else {
				return c.JSON(http.StatusInternalServerError, err.Error())
			}
		}

		if !data {
			return c.JSON(http.StatusInternalServerError, "cannot delete")
		}

		return c.JSON(http.StatusOK, map[string]interface{}{
			"message": "success delete book",
		})
	}
}

func (bh *bookHandler) UpdateBook() echo.HandlerFunc {
	return func(c echo.Context) error {
		qry := map[string]interface{}{}
		cnv, err := strconv.Atoi(c.Param("id"))
		if err != nil {
			log.Println("Cannot convert to int", err.Error())
			return c.JSON(http.StatusInternalServerError, "cannot convert id")
		}

		var tmp BookInsertRequest
		res := c.Bind(&tmp)

		if res != nil {
			log.Println("Cannot parse data", err)
			c.JSON(http.StatusBadRequest, "error read input")
		}

		if tmp.Judul != "" {
			qry["Judul"] = tmp.Judul
		}

		if tmp.Penerbit != "" {
			qry["Author"] = tmp.Penerbit
		}

		data, err := bh.bookUsecase.UpBook(cnv, tmp.ToDomain())

		if err != nil {
			log.Println("Cannot update data", err)
			c.JSON(http.StatusInternalServerError, err)
		}

		return c.JSON(http.StatusCreated, map[string]interface{}{
			"message": "success update data",
			// "data": data,
			"ID":       data.ID,
			"Judul":    data.Judul,
			"Penerbit": data.Penerbit,
			"Pemilik":  common.ExtractData(c),
		})
	}
}
