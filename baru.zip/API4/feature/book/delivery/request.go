package delivery

import "API4/domain"

type BookInsertRequest struct {
	Judul    string `json:"judul"`
	Penerbit string `json:"penerbit"`
}

func (bi *BookInsertRequest) ToDomain() domain.Book {
	return domain.Book{
		Judul:    bi.Judul,
		Penerbit: bi.Penerbit,
	}
}
