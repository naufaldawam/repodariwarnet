package delivery

import (
	"API4/config"
	"API4/domain"
	"API4/feature/user/delivery/middlewares"

	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
)

func RouteBook(e *echo.Echo, bc domain.BookHandler) {
	e.GET("/books", bc.GetAllBook())
	e.GET("/book", bc.GetMyBook(), middleware.JWTWithConfig(middlewares.UseJWT([]byte(config.SECRET))))
	e.POST("/book", bc.InsertBook(), middleware.JWTWithConfig(middlewares.UseJWT([]byte(config.SECRET))))
	e.DELETE("/book/:id", bc.DeleteBook(), middleware.JWTWithConfig(middlewares.UseJWT([]byte(config.SECRET))))
	e.PUT("/book/:id", bc.UpdateBook(), middleware.JWTWithConfig(middlewares.UseJWT([]byte(config.SECRET))))
}
