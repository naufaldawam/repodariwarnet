package usecase

import (
	"errors"

	"API4/domain"

	"github.com/google/uuid"
)

type bookUseCase struct {
	data domain.BookData
}

func New(model domain.BookData) domain.BookUseCase {
	return &bookUseCase{
		data: model,
	}
}

func (bu *bookUseCase) AddBook(IDUser int, newBook domain.Book) (domain.Book, error) {
	if IDUser == -1 {
		return domain.Book{}, errors.New("invalid user")
	}

	uidGen := uuid.New
	newBook.ISBN = uidGen().String()
	newBook.Pemilik = IDUser

	res := bu.data.Insert(newBook)
	if res.ID == 0 {
		return domain.Book{}, errors.New("error insert book")
	}

	return res, nil
}

func (bu *bookUseCase) GetAllB() ([]domain.Book, error) {
	res := bu.data.GetAll()

	if len(res) == 0 {
		return nil, errors.New("no data found")
	}

	return res, nil
}

func (bu *bookUseCase) GetMyB(IDUser int) ([]domain.Book, error) {

	if IDUser == -1 {
		return nil, errors.New("invalid user")
	}

	res := bu.data.GetMy(IDUser)
	// if res.ID == 0 {
	// 	return nil, errors.New("no data found")
	// }

	return res, nil

}

func (bu *bookUseCase) DelBook(IDBook int) (bool, error) {
	res := bu.data.Delete(IDBook)

	if !res {
		return false, errors.New("failed delete")
	}

	return true, nil
}

func (bu *bookUseCase) UpBook(IDBook int, updateData domain.Book) (domain.Book, error) {
	if IDBook == -1 {
		return domain.Book{}, errors.New("invalid book")
	}

	res := bu.data.Update(IDBook, updateData)
	if res.ID == 0 {
		return domain.Book{}, errors.New("error update book")
	}

	return res, nil
}
