package data

import (
	"log"

	"API4/domain"

	"gorm.io/gorm"
)

type bookData struct {
	db *gorm.DB
}

func New(db *gorm.DB) domain.BookData {
	return &bookData{
		db: db,
	}
}

func (bd *bookData) GetAll() []domain.Book {
	var data []Book
	err := bd.db.Find(&data)

	if err.Error != nil {
		log.Println("error on select data", err.Error.Error())
		return nil
	}

	return ParseToArrDomain(data)
}

func (bd *bookData) GetMy(userID int) []domain.Book {
	var data []Book
	err := bd.db.Where("Pemilik = ?", userID).Find(&data)

	if err.Error != nil {
		log.Println("There is problem with data", err.Error.Error())
		return nil
	}
	return ParseToArrDomain(data)
}

func (bd *bookData) Insert(newBook domain.Book) domain.Book {
	cnv := ToLocal(newBook)
	err := bd.db.Create(&cnv)
	if err.Error != nil {
		log.Println("Cannot insert data", err.Error.Error())
		return domain.Book{}
	}

	return cnv.ToDomain()
}

func (bd *bookData) Delete(bookID int) bool {
	err := bd.db.Where("ID = ?", bookID).Delete(&Book{})
	if err.Error != nil {
		log.Println("Cannot delete data", err.Error.Error())
		return false
	}
	if err.RowsAffected < 1 {
		log.Println("No data deleted", err.Error.Error())
		return false
	}
	return true
}

func (bd *bookData) Update(bookID int, updatedBook domain.Book) domain.Book {
	cnv := ToLocal(updatedBook)
	err := bd.db.Model(&cnv).Where("ID = ?", bookID).Updates(updatedBook)
	if err.Error != nil {
		log.Println("Cannot update data", err.Error.Error())
		return domain.Book{}
	}
	cnv.ID = uint(bookID)
	return cnv.ToDomain()
}
