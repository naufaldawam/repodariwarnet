package delivery

import (
	"API4/config"
	"API4/domain"
	"API4/feature/user/delivery/middlewares"

	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
)

func RouteBook(e *echo.Echo, bc domain.UserHandler) {
	e.POST("/profile", bc.InsertUser())
	e.GET("/users", bc.GetAllUser())
	e.GET("/profile", bc.GetUser(), middleware.JWTWithConfig(middlewares.UseJWT([]byte(config.SECRET))))
	e.DELETE("/profile", bc.DeleteUser(), middleware.JWTWithConfig(middlewares.UseJWT([]byte(config.SECRET))))
	e.PUT("/profile", bc.UpdateUser(), middleware.JWTWithConfig(middlewares.UseJWT([]byte(config.SECRET))))
}
